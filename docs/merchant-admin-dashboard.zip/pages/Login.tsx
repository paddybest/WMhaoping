import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import { API_BASE_URL } from '../constants';
import { connectSocket } from '../services/socket';
import { Lock, User, Info } from 'lucide-react';

export const Login: React.FC = () => {
  const [username, setUsername] = useState('admin');
  const [password, setPassword] = useState('admin');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    // --- DEMO BYPASS ---
    // Since backend might not be running, we allow a specific demo account to log in.
    if (username === 'admin' && password === 'admin') {
      setTimeout(() => {
        const mockToken = 'mock_jwt_token_for_demo_12345';
        localStorage.setItem('token', mockToken);
        // Attempt to connect socket, though it might fail silently if server is down
        connectSocket(mockToken);
        navigate('/');
        setLoading(false);
      }, 800);
      return;
    }
    // -------------------

    try {
      const res = await axios.post(`${API_BASE_URL}/auth/merchant/login`, { username, password });
      const { access_token } = res.data;
      
      localStorage.setItem('token', access_token);
      connectSocket(access_token);
      
      navigate('/');
    } catch (err: any) {
      console.error(err);
      setError(err.response?.data?.message || '登录失败。请检查您的凭证或确保后端服务正在运行。');
    } finally {
      if (!(username === 'admin' && password === 'admin')) {
        setLoading(false);
      }
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 flex items-center justify-center p-4">
      <div className="max-w-md w-full bg-white rounded-xl shadow-lg p-8">
        <div className="text-center mb-8">
          <h1 className="text-2xl font-bold text-gray-900">商家后台管理系统</h1>
          <p className="text-gray-500 text-sm mt-2">请登录以管理您的店铺</p>
        </div>

        {error && (
          <div className="mb-4 p-3 bg-red-50 text-red-600 text-sm rounded-lg border border-red-100">
            {error}
          </div>
        )}

        <div className="mb-6 p-3 bg-blue-50 text-blue-700 text-sm rounded-lg border border-blue-100 flex items-start">
          <Info size={18} className="mr-2 mt-0.5 flex-shrink-0" />
          <div>
            <span className="font-semibold">演示账号：</span>
            <br />
            用户名: <strong>admin</strong>
            <br />
            密码: <strong>admin</strong>
          </div>
        </div>

        <form onSubmit={handleLogin} className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">用户名</label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <User size={18} className="text-gray-400" />
              </div>
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500 sm:text-sm transition-colors"
                placeholder="请输入用户名"
                required
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">密码</label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Lock size={18} className="text-gray-400" />
              </div>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500 sm:text-sm transition-colors"
                placeholder="请输入密码"
                required
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className={`
              w-full flex justify-center py-2.5 px-4 border border-transparent rounded-lg shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500
              ${loading ? 'opacity-75 cursor-not-allowed' : ''}
            `}
          >
            {loading ? '登录中...' : '登录'}
          </button>
        </form>
      </div>
    </div>
  );
};