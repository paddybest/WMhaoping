import React, { useState, useEffect } from 'react';
import api from '../services/api';
import { Category } from '../types';
import { Plus, Pencil, Trash2, X, Search, ChevronLeft, ChevronRight, Loader2, AlertCircle } from 'lucide-react';

export const Categories: React.FC = () => {
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(false);
  
  // Pagination & Search state
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [totalItems, setTotalItems] = useState(0);
  const [searchKeyword, setSearchKeyword] = useState('');
  const [debouncedSearch, setDebouncedSearch] = useState('');

  // Modal state
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [currentCategory, setCurrentCategory] = useState<Partial<Category>>({});
  const [isSaving, setIsSaving] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  // Debounce search
  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedSearch(searchKeyword);
      setCurrentPage(1); // Reset to page 1 on search
    }, 500);
    return () => clearTimeout(timer);
  }, [searchKeyword]);

  useEffect(() => {
    fetchCategories();
  }, [currentPage, debouncedSearch]);

  const fetchCategories = async () => {
    setLoading(true);
    try {
      const params: any = { page: currentPage, per_page: 10 };
      if (debouncedSearch) params.name = debouncedSearch;

      const res = await api.get('/categories', { params });
      
      // Handle different API response structures (paginated vs array)
      const data = res.data?.data;
      if (data && Array.isArray(data.items)) {
        setCategories(data.items);
        setTotalItems(data.total);
        setTotalPages(Math.ceil(data.total / 10));
      } else if (Array.isArray(data)) {
        // Fallback for simple array response (client-side pagination simulation)
        setCategories(data);
        setTotalItems(data.length);
        setTotalPages(1);
      } else {
        setCategories([]);
        setTotalItems(0);
      }
    } catch (e) {
      console.error("Failed to fetch categories", e);
      // Mock data logic for demonstration if API fails
      if (!debouncedSearch) {
        setCategories([
          { id: 1, name: '美食', sort_order: 1 },
          { id: 2, name: '服务', sort_order: 2 },
          { id: 3, name: '环境', sort_order: 3 },
          { id: 4, name: '价格', sort_order: 4 },
          { id: 5, name: '卫生', sort_order: 5 },
        ]);
        setTotalItems(5);
        setTotalPages(1);
      } else {
        setCategories([]);
        setTotalItems(0);
      }
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id: number) => {
    if (!window.confirm('确定要删除该类目吗？此操作不可恢复。')) return;
    
    try {
      await api.delete(`/categories/${id}`);
      fetchCategories(); // Refresh list
    } catch (e: any) {
      const msg = e.response?.data?.message || '删除失败，请检查该类目下是否仍有标签关联。';
      alert(msg);
    }
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');
    
    if (!currentCategory.name?.trim()) {
        setErrorMessage('类目名称不能为空');
        return;
    }

    setIsSaving(true);
    try {
      const payload = {
        name: currentCategory.name,
        sort_order: Number(currentCategory.sort_order) || 0
      };

      if (currentCategory.id) {
        await api.put(`/categories/${currentCategory.id}`, payload);
      } else {
        await api.post('/categories', payload);
      }
      setIsModalOpen(false);
      fetchCategories();
    } catch (e: any) {
      setErrorMessage(e.response?.data?.message || '保存失败，请重试');
    } finally {
      setIsSaving(false);
    }
  };

  const openModal = (category?: Category) => {
      setErrorMessage('');
      setCurrentCategory(category || { sort_order: 0, name: '' });
      setIsModalOpen(true);
  };

  return (
    <div className="space-y-6">
      {/* Header Section */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">类目管理</h1>
          <p className="text-sm text-gray-500 mt-1">管理商品或服务的评价分类维度</p>
        </div>
        <button 
          onClick={() => openModal()}
          className="bg-blue-600 text-white px-4 py-2.5 rounded-lg hover:bg-blue-700 flex items-center justify-center shadow-sm transition-all"
        >
          <Plus size={18} className="mr-2" />
          新建类目
        </button>
      </div>

      {/* Search Bar */}
      <div className="bg-white p-4 rounded-xl shadow-sm border border-gray-100 flex items-center">
        <div className="relative flex-1 max-w-md">
          <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
          <input 
            type="text" 
            placeholder="搜索类目名称..."
            value={searchKeyword}
            onChange={(e) => setSearchKeyword(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all"
          />
        </div>
      </div>

      {/* Table Section */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden relative">
        {loading && (
          <div className="absolute inset-0 bg-white/70 z-10 flex items-center justify-center">
            <Loader2 size={32} className="animate-spin text-blue-600" />
          </div>
        )}
        
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider w-20">ID</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">类目名称</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider w-32">排序值</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider w-40">操作</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {categories.length > 0 ? (
                categories.map((cat) => (
                  <tr key={cat.id} className="hover:bg-gray-50 transition-colors">
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">#{cat.id}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{cat.name}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
                        {cat.sort_order}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                      <button 
                        onClick={() => openModal(cat)}
                        className="text-blue-600 hover:text-blue-900 mr-4 inline-flex items-center"
                        title="编辑"
                      >
                        <Pencil size={16} />
                      </button>
                      <button 
                        onClick={() => handleDelete(cat.id)}
                        className="text-red-600 hover:text-red-900 inline-flex items-center"
                        title="删除"
                      >
                        <Trash2 size={16} />
                      </button>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={4} className="px-6 py-12 text-center text-gray-500">
                    {loading ? '加载中...' : '暂无数据'}
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination Footer */}
        {totalItems > 0 && (
          <div className="px-6 py-4 border-t border-gray-100 flex items-center justify-between bg-gray-50">
            <div className="text-sm text-gray-500">
              共 <span className="font-medium">{totalItems}</span> 条数据
            </div>
            <div className="flex items-center space-x-2">
              <button 
                onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                disabled={currentPage === 1}
                className="p-1 rounded-md border border-gray-300 bg-white text-gray-600 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <ChevronLeft size={18} />
              </button>
              <span className="text-sm text-gray-700 px-2">
                第 {currentPage} / {totalPages} 页
              </span>
              <button 
                onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                disabled={currentPage === totalPages}
                className="p-1 rounded-md border border-gray-300 bg-white text-gray-600 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <ChevronRight size={18} />
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-2xl w-full max-w-md overflow-hidden transform transition-all">
            <div className="px-6 py-4 border-b border-gray-100 flex justify-between items-center bg-gray-50">
              <h2 className="text-lg font-bold text-gray-800">
                {currentCategory.id ? '编辑类目' : '新建类目'}
              </h2>
              <button onClick={() => setIsModalOpen(false)} className="text-gray-400 hover:text-gray-600 transition-colors">
                <X size={20} />
              </button>
            </div>
            
            <form onSubmit={handleSave} className="p-6 space-y-4">
              {errorMessage && (
                <div className="p-3 bg-red-50 text-red-600 text-sm rounded-lg flex items-start">
                  <AlertCircle size={16} className="mr-2 mt-0.5 flex-shrink-0" />
                  {errorMessage}
                </div>
              )}
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  类目名称 <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={currentCategory.name || ''}
                  onChange={e => setCurrentCategory({ ...currentCategory, name: e.target.value })}
                  className="w-full border border-gray-300 rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500 outline-none transition-shadow"
                  placeholder="例如：口味、服务"
                  autoFocus
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  排序值
                </label>
                <input
                  type="number"
                  value={currentCategory.sort_order ?? 0}
                  onChange={e => setCurrentCategory({ ...currentCategory, sort_order: Number(e.target.value) })}
                  className="w-full border border-gray-300 rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500 outline-none transition-shadow"
                  placeholder="数值越小越靠前"
                />
                <p className="text-xs text-gray-500 mt-1">控制在前端展示的顺序，数值越小越靠前</p>
              </div>

              <div className="flex justify-end space-x-3 pt-4">
                <button 
                  type="button" 
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200 font-medium transition-colors"
                >
                  取消
                </button>
                <button 
                  type="submit"
                  disabled={isSaving}
                  className={`
                    px-4 py-2 text-white rounded-lg font-medium flex items-center shadow-sm transition-all
                    ${isSaving ? 'bg-blue-400 cursor-not-allowed' : 'bg-blue-600 hover:bg-blue-700 hover:shadow-md'}
                  `}
                >
                  {isSaving && <Loader2 size={16} className="animate-spin mr-2" />}
                  {isSaving ? '保存中...' : '确认保存'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};