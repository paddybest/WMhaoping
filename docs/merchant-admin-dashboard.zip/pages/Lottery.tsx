import React, { useState, useEffect } from 'react';
import api from '../services/api';
import { Prize, LotteryRecord } from '../types';
import { Gift, History, Plus } from 'lucide-react';

export const Lottery: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'prizes' | 'records'>('prizes');
  const [prizes, setPrizes] = useState<Prize[]>([]);
  const [records, setRecords] = useState<LotteryRecord[]>([]);

  useEffect(() => {
    if (activeTab === 'prizes') {
        // Mock fetch prizes
        setPrizes([
            { id: 1, name: 'iPhone 15', image_url: '', stock: 5, probability: 0.01 },
            { id: 2, name: '10元优惠券', image_url: '', stock: 100, probability: 0.5 },
        ]);
    } else {
        // Mock fetch records
        setRecords([
            { id: 101, user_id: 1, user_nickname: 'Alice', prize_name: '10元优惠券', created_at: '2023-10-28 10:00' }
        ]);
    }
  }, [activeTab]);

  return (
    <div className="space-y-6">
      <div className="flex space-x-4 border-b border-gray-200">
        <button
          onClick={() => setActiveTab('prizes')}
          className={`pb-3 px-1 font-medium text-sm transition-colors border-b-2 ${activeTab === 'prizes' ? 'border-blue-600 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700'}`}
        >
          <div className="flex items-center"><Gift size={16} className="mr-2"/> 奖品设置</div>
        </button>
        <button
          onClick={() => setActiveTab('records')}
          className={`pb-3 px-1 font-medium text-sm transition-colors border-b-2 ${activeTab === 'records' ? 'border-blue-600 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700'}`}
        >
          <div className="flex items-center"><History size={16} className="mr-2"/> 抽奖记录</div>
        </button>
      </div>

      {activeTab === 'prizes' ? (
        <div className="space-y-4">
            <div className="flex justify-end">
                <button className="bg-blue-600 text-white px-4 py-2 rounded-lg flex items-center text-sm font-medium">
                    <Plus size={16} className="mr-2"/> 添加奖品
                </button>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {prizes.map(prize => (
                    <div key={prize.id} className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 flex flex-col items-center text-center">
                        <div className="h-24 w-24 bg-gray-100 rounded-full mb-4 flex items-center justify-center text-gray-300">
                            <Gift size={40} />
                        </div>
                        <h3 className="font-bold text-gray-900">{prize.name}</h3>
                        <div className="mt-2 text-sm text-gray-500 space-y-1">
                            <p>库存: {prize.stock}</p>
                            <p>概率: {prize.probability * 100}%</p>
                        </div>
                        <div className="mt-4 flex space-x-2 w-full">
                            <button className="flex-1 py-2 text-blue-600 bg-blue-50 rounded-lg text-sm font-medium hover:bg-blue-100">编辑</button>
                        </div>
                    </div>
                ))}
            </div>
        </div>
      ) : (
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
             <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                    <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">用户</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">奖品</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">时间</th>
                    </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                    {records.map(r => (
                        <tr key={r.id}>
                            <td className="px-6 py-4 text-sm text-gray-900">{r.user_nickname}</td>
                            <td className="px-6 py-4 text-sm text-green-600 font-medium">{r.prize_name}</td>
                            <td className="px-6 py-4 text-sm text-gray-500">{r.created_at}</td>
                        </tr>
                    ))}
                </tbody>
             </table>
        </div>
      )}
    </div>
  );
};