import React, { useState, useEffect } from 'react';
import api from '../services/api';
import { MerchantProfile } from '../types';
import { Save, Store, Phone, MapPin, FileText, User } from 'lucide-react';

export const MerchantInfo: React.FC = () => {
  const [profile, setProfile] = useState<MerchantProfile | null>(null);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error', text: string } | null>(null);

  useEffect(() => {
    fetchProfile();
  }, []);

  const fetchProfile = async () => {
    setLoading(true);
    try {
      // In real app: const res = await api.get('/merchant/profile');
      // Mock data for now
      setTimeout(() => {
        setProfile({
          id: 1,
          username: 'admin',
          store_name: '我的示例店铺',
          contact_phone: '13800138000',
          address: '上海市浦东新区陆家嘴环路1000号',
          description: '这是一家主营特色美食的店铺，欢迎光临！'
        });
        setLoading(false);
      }, 500);
    } catch (e) {
      console.error(e);
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!profile) return;

    setSaving(true);
    setMessage(null);
    try {
      // In real app: await api.put('/merchant/profile', profile);
      // Mock delay
      await new Promise(resolve => setTimeout(resolve, 800));
      setMessage({ type: 'success', text: '商家信息更新成功！' });
    } catch (e) {
      setMessage({ type: 'error', text: '更新失败，请重试。' });
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return <div className="text-center py-10 text-gray-500">加载中...</div>;
  }

  if (!profile) return null;

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div className="flex items-center space-x-3 mb-6">
        <h1 className="text-2xl font-bold text-gray-800">商家信息设置</h1>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="p-6 border-b border-gray-100 bg-gray-50 flex items-center justify-between">
            <div className="flex items-center space-x-4">
                <div className="h-16 w-16 bg-blue-100 rounded-full flex items-center justify-center text-blue-600 font-bold text-2xl">
                    {profile.store_name?.[0] || '店'}
                </div>
                <div>
                    <h2 className="text-lg font-bold text-gray-900">{profile.store_name}</h2>
                    <p className="text-sm text-gray-500">账号: {profile.username}</p>
                </div>
            </div>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          {message && (
            <div className={`p-4 rounded-lg text-sm ${message.type === 'success' ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700'}`}>
              {message.text}
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
             <div className="col-span-1 md:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-1 flex items-center">
                    <Store size={16} className="mr-2 text-gray-400"/> 店铺名称
                </label>
                <input
                  type="text"
                  value={profile.store_name}
                  onChange={e => setProfile({ ...profile, store_name: e.target.value })}
                  className="w-full border border-gray-300 rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500 outline-none transition-all"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1 flex items-center">
                    <User size={16} className="mr-2 text-gray-400"/> 用户名 (只读)
                </label>
                <input
                  type="text"
                  value={profile.username}
                  className="w-full border border-gray-200 bg-gray-50 rounded-lg p-2.5 text-gray-500 cursor-not-allowed"
                  disabled
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1 flex items-center">
                    <Phone size={16} className="mr-2 text-gray-400"/> 联系电话
                </label>
                <input
                  type="text"
                  value={profile.contact_phone || ''}
                  onChange={e => setProfile({ ...profile, contact_phone: e.target.value })}
                  className="w-full border border-gray-300 rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500 outline-none transition-all"
                />
              </div>

              <div className="col-span-1 md:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-1 flex items-center">
                    <MapPin size={16} className="mr-2 text-gray-400"/> 店铺地址
                </label>
                <input
                  type="text"
                  value={profile.address || ''}
                  onChange={e => setProfile({ ...profile, address: e.target.value })}
                  className="w-full border border-gray-300 rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500 outline-none transition-all"
                />
              </div>

              <div className="col-span-1 md:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-1 flex items-center">
                    <FileText size={16} className="mr-2 text-gray-400"/> 店铺简介
                </label>
                <textarea
                  rows={4}
                  value={profile.description || ''}
                  onChange={e => setProfile({ ...profile, description: e.target.value })}
                  className="w-full border border-gray-300 rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500 outline-none transition-all"
                />
              </div>
          </div>

          <div className="flex justify-end pt-4">
            <button
              type="submit"
              disabled={saving}
              className={`
                flex items-center px-6 py-2.5 rounded-lg text-white font-medium shadow-sm transition-all
                ${saving ? 'bg-blue-400 cursor-not-allowed' : 'bg-blue-600 hover:bg-blue-700 hover:shadow-md'}
              `}
            >
              <Save size={18} className="mr-2" />
              {saving ? '保存中...' : '保存修改'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};