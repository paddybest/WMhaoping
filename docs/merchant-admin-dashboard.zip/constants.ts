export const API_BASE_URL = 'http://localhost:5000/api';
export const SOCKET_URL = 'http://localhost:5000';

export const MENU_ITEMS = [
  { path: '/', label: '仪表盘', icon: 'LayoutDashboard' },
  { path: '/categories', label: '类目管理', icon: 'List' },
  { path: '/tags', label: '标签管理', icon: 'Tags' },
  { path: '/users', label: '用户管理', icon: 'Users' },
  { path: '/evaluations', label: '评价管理', icon: 'MessageSquare' },
  { path: '/lottery', label: '抽奖管理', icon: 'Gift' },
  { path: '/merchant', label: '商家信息', icon: 'Store' },
];